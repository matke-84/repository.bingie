#!/usr/bin/python
# -*- coding: utf-8 -*-

from resources.lib.main_module import MainModule
MainModule()
